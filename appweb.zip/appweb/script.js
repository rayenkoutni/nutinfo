// ======= Flying sprites canvas =======
const spriteCanvas = document.getElementById('sprites');
const spriteCtx = spriteCanvas.getContext('2d');
let sprites = [];

function resizeCanvas(canvas) {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
resizeCanvas(spriteCanvas);
window.addEventListener('resize', () => resizeCanvas(spriteCanvas));

// Sprite definitions
const spriteTypes = [
    { // Pac-Man ghost
        draw: (ctx, x, y, hue) => {
            ctx.save();
            ctx.translate(x, y);
            ctx.rotate(Math.sin(Date.now() * 0.001 + x) * 0.1);
            ctx.shadowBlur = 10;
            ctx.shadowColor = `hsl(${hue},100%,50%)`;
            ctx.fillStyle = `hsl(${hue},100%,50%)`;
            ctx.beginPath();
            ctx.arc(0, -8, 8, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillRect(-8, -8, 16, 12);
            ctx.beginPath();
            ctx.moveTo(-6, -2); ctx.lineTo(-4, 2); ctx.lineTo(-2, 0);
            ctx.moveTo(6, -2); ctx.lineTo(4, 2); ctx.lineTo(2, 0);
            ctx.lineWidth = 2;
            ctx.strokeStyle = '#fff';
            ctx.stroke();
            ctx.restore();
        }
    },
    { // Space Invaders ship
        draw: (ctx, x, y, hue) => {
            ctx.save();
            ctx.translate(x, y);
            ctx.shadowBlur = 15;
            ctx.shadowColor = `hsl(${hue},100%,60%)`;
            ctx.fillStyle = `hsl(${hue},100%,40%)`;
            ctx.fillRect(-12, -6, 24, 12);
            ctx.fillStyle = `hsl(${hue},100%,60%)`;
            ctx.fillRect(-8, -10, 16, 6);
            ctx.fillStyle = '#fff';
            ctx.fillRect(-3, -14, 6, 6);
            ctx.restore();
        }
    }
];

// Create sprites
for(let i = 0; i < 8; i++) {
    sprites.push({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        type: Math.floor(Math.random() * spriteTypes.length),
        hue: Math.random() * 360
    });
}

function animateSprites() {
    spriteCtx.clearRect(0, 0, spriteCanvas.width, spriteCanvas.height);
    sprites.forEach(sprite => {
        sprite.x += sprite.vx;
        sprite.y += sprite.vy;
        sprite.hue += 0.5;

        if(sprite.x < -50 || sprite.x > spriteCanvas.width + 50 || 
           sprite.y < -50 || sprite.y > spriteCanvas.height + 50){
            sprite.x = Math.random() * spriteCanvas.width;
            sprite.y = Math.random() * spriteCanvas.height;
            sprite.vx = (Math.random() - 0.5) * 0.8;
            sprite.vy = (Math.random() - 0.5) * 0.8;
        }
        spriteTypes[sprite.type].draw(spriteCtx, sprite.x, sprite.y, sprite.hue);
    });
    requestAnimationFrame(animateSprites);
}

// ======= Scanlines =======
const scanCanvas = document.getElementById('scanlines');
const scanCtx = scanCanvas.getContext('2d');
resizeCanvas(scanCanvas);
window.addEventListener('resize', () => resizeCanvas(scanCanvas));

let scanLine = 0;
function animateScanlines() {
    scanCtx.clearRect(0,0,scanCanvas.width,scanCanvas.height);
    for(let i = 0; i < 20; i++){
        const x = (i / 20) * scanCanvas.width;
        scanCtx.strokeStyle = `rgba(0,255,65,${0.1 + Math.sin(Date.now()*0.001 + i)*0.05})`;
        scanCtx.lineWidth = 2;
        scanCtx.shadowBlur = 10;
        scanCtx.shadowColor = '#00ff41';
        scanCtx.beginPath();
        scanCtx.moveTo(x + Math.sin(scanLine*0.1+i)*20, 0);
        scanCtx.lineTo(x + Math.sin(scanLine*0.1+i+0.5)*20, scanCanvas.height);
        scanCtx.stroke();
    }
    scanCtx.strokeStyle = 'rgba(0,255,65,0.3)';
    scanCtx.lineWidth = 3;
    scanCtx.shadowBlur = 20;
    scanCtx.shadowColor = '#00ff41';
    scanCtx.beginPath();
    scanCtx.moveTo(0, scanLine % scanCanvas.height);
    scanCtx.lineTo(scanCanvas.width, scanLine % scanCanvas.height);
    scanCtx.stroke();
    scanLine += 2;
    requestAnimationFrame(animateScanlines);
}

// ======= Leaderboard fetching =======
async function loadLeaderboard() {
    const tbody = document.querySelector('tbody');
    if (!tbody) { 
        console.error("Leaderboard tbody not found!");
        return; 
    }

    try {
        // If you serve the page from the same origin as the API, use a relative path: '/api/leaderboard'
        const response = await fetch('http://127.0.0.1:5000/api/leaderboard', {cache: 'no-store'});
        if (!response.ok) throw new Error("Network response was not ok");
        const leaderboard = await response.json();

        // Clear existing rows
        tbody.innerHTML = '';

        let rank = 1;
        for (const [teamName, data] of Object.entries(leaderboard)) {
            const projects = Array.isArray(data.projects) ? data.projects : [];
            const status = projects.length > 0 ? 'ALIVE' : 'IDLE';

            // Build projects HTML safely
            const projectHtml = projects.length
                ? `<div class="project-list">${projects.map(p => {
                    const safeName = String(p.name ?? '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
                    return `<div>${safeName}</div>`;
                }).join('')}</div>`
                : `<div class="project-list"><div style="opacity:.5">— no projects —</div></div>`;

            const row = document.createElement('tr');
            row.innerHTML = `
                <td class="rank">${rank}</td>
                <td>${teamName}</td>
                <td class="score">${projectHtml}</td>
                <td>${projects.length}</td>
                <td class="status ${projects.length>0 ? 'alive' : 'gameover'}">${status}</td>
            `;
            tbody.appendChild(row);
            rank++;
        }

        // if empty, show helpful message
        if (rank === 1) {
            const emptyRow = document.createElement('tr');
            emptyRow.innerHTML = `<td colspan="5" style="padding:20px;text-align:center;color:#00cc33;opacity:.9">No teams found — click refresh or start scraping.</td>`;
            tbody.appendChild(emptyRow);
        }
    } catch (err) {
        console.error('Error loading leaderboard:', err);
        // show a visible error row
        const tbodyEl = document.querySelector('tbody');
        if (tbodyEl) {
            tbodyEl.innerHTML = `<tr><td colspan="5" style="padding:20px;text-align:center;color:#ff6666">Failed to load leaderboard (check server / CORS). See console for details.</td></tr>`;
        }
    }
}

// ======= Initialize everything =======
document.addEventListener('DOMContentLoaded', () => {
    animateSprites();
    animateScanlines();
    loadLeaderboard();
    setInterval(loadLeaderboard, 10000); // Refresh every 10s
});
